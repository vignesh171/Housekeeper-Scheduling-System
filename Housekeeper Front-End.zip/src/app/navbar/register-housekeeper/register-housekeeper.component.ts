import { Component } from '@angular/core';
import { RegHouseKeeperServiceService } from '../../service/reg-house-keeper-service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Worker } from 'src/app/worker.model';
// import { Worker } from '.app/worker.model.ts';

@Component({
  selector: 'app-register-housekeeper',
  templateUrl: './register-housekeeper.component.html',
  styleUrls: ['./register-housekeeper.component.css'],
})
export class RegisterHousekeeperComponent {  

hostel: any;
  WorkerDetails: Worker[] = [];
  selectedWorker: Worker | null = null; // To hold the worker being edited

  constructor(
    private snackBar: MatSnackBar,
    private route: Router,
    private houseKeeperService: RegHouseKeeperServiceService,
    private activateRoute: ActivatedRoute
  ) {
    if (!localStorage.getItem('AdminLoginId')) {
      this.route.navigateByUrl('/adminlogin');
    }
    this.hostel = this.activateRoute.snapshot.paramMap.get('id');
    this.loadWorkerDetails();
  }

  loadWorkerDetails() {
    this.houseKeeperService
      .getWorkerByNameAndFloor(this.hostel)
      .subscribe((item) => {
        this.WorkerDetails = item;
      });
  }

  registerHousekeeper(data: Worker) {
    this.houseKeeperService
      .registerHousekeeper(data, this.hostel)
      .subscribe(() => {
        this.snackBar.open('Housekeeper Register successful', 'Close');
        this.loadWorkerDetails(); // Refresh list
      });
  }

  editWorker(worker: Worker) {
    this.selectedWorker = { ...worker }; // Make a copy for editing
  }

  updateWorker() {
    if (this.selectedWorker) {
      this.houseKeeperService
        .updateWorker(this.selectedWorker.worker_id, this.selectedWorker)
        .subscribe(() => {
          this.snackBar.open('Housekeeper updated successfully', 'Close');
          this.selectedWorker = null; // Clear the selected worker
          this.loadWorkerDetails(); // Refresh list
        });
    }
  }

  deleteWorker(workerId: number) {
    this.houseKeeperService
      .deleteWorker(workerId)
      .subscribe(() => {
        this.snackBar.open('Housekeeper deleted successfully', 'Close');
        this.loadWorkerDetails(); // Refresh list
      });
  }
}



