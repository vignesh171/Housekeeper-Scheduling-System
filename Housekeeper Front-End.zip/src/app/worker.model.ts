export class Worker {
    worker_id!: number;
    name!: string;
    floor!: number;
    hostel!: string;
   
  }
  