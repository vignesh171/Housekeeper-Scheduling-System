import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Worker } from '../worker.model';

@Injectable({
  providedIn: 'root'
})
export class RegHouseKeeperServiceService {


private url: string = 'http://localhost:8087/';

constructor(private http: HttpClient) { }

registerHousekeeper(data: Worker, hostel: any): Observable<Worker> {
  return this.http.post<Worker>(`${this.url}registerWorker/${hostel}`, data);
}

getHouseKeeperByFloor(data: any, hostel: any): Observable<Worker[]> {
  return this.http.get<Worker[]>(`${this.url}getHouseKeeperByFloor/${data}/${hostel}`);
}

getWorkerByNameAndFloor(data: any): Observable<Worker[]> {
  return this.http.get<Worker[]>(`${this.url}getWorkerByNameAndFloor/${data}`);
}

deleteWorker(workerId: number): Observable<void> {
  return this.http.delete<void>(`${this.url}deleteWorker/${workerId}`);
}


updateWorker(workerId: number, worker: Worker): Observable<Worker> {
  return this.http.put<Worker>(`${this.url}updateWorker/${workerId}`, worker);
}


}
